# Risk treatment plan

> Version: 2026-02-26  
> Owner: Andrea Gagliardi

## Principles
For each risk:
- avoid / reduce / transfer / accept
- define controls, owner, due date, evidence

Operational detail is maintained in `03_risk_management/risk_register.yaml`.
