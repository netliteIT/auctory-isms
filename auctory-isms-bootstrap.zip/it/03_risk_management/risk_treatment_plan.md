# Piano di trattamento del rischio

> Versione: 2026-02-26  
> Proprietario: Andrea Gagliardi

## Principi
Per ciascun rischio:
- evitare / ridurre / trasferire / accettare
- definire controlli, owner, scadenza, evidenze

Il dettaglio operativo è mantenuto in `03_risk_management/risk_register.yaml`.
